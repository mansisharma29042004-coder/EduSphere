
document.addEventListener("DOMContentLoaded", function () {
    // Automatically hide notification messages
    const alerts = document.querySelectorAll(".alert");

    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = "opacity .5s";
            alert.style.opacity = "0";

            setTimeout(function () {
                alert.remove();
            }, 500);
        }, 4000);
    });

    // Add a small hover tilt effect to feature cards
    document.querySelectorAll(".feature-card").forEach(function(card) {
        card.addEventListener("mousemove", function(event) {
            const rect = card.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;

            const rotateY = ((x / rect.width) - 0.5) * 8;
            const rotateX = ((0.5 - y / rect.height)) * 8;

            card.style.transform =
                `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-5px)`;
        });

        card.addEventListener("mouseleave", function() {
            card.style.transform = "";
        });
    });
});
