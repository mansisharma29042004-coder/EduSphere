
document.addEventListener("DOMContentLoaded", function() {
    console.log("EduSphere dashboard scripts loaded successfully.");
});
