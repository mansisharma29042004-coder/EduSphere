
document.addEventListener("DOMContentLoaded", function() {
    // Highlight the current admin page in the sidebar
    const currentPath = window.location.pathname;

    document.querySelectorAll(".sidebar a").forEach(function(link) {
        if (link.getAttribute("href") === currentPath) {
            link.classList.add("active");
        }
    });
});
